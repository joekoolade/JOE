function run() {
    print("global run method");
}

var intfObj = {
    run: function() { print("object run method"); }
};
