function main(name) {
    print(name);
}

var scriptObj = {
    main: function(name) { print(name); }
};
