var res = 45 + 34;
